import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import datetime

class NexusModel:
    GENERIC = "Generic"
    N93180YC_EX = "Nexus 93180YC-EX"
    N9336C_FX2 = "Nexus 9336C-FX2"
    N9348GC_FXP = "Nexus 9348GC-FXP"

class NexusConfiguratorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Cisco Nexus Configurator - Advanced v2")
        self.root.geometry("1100x950")
        
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Variables
        self.mode_var = tk.StringVar(value="Standalone")
        self.model_var = tk.StringVar(value=NexusModel.GENERIC)
        
        # Admin User Variables
        self.admin_user_var = tk.StringVar(value="admin")
        self.admin_pass_var = tk.StringVar()
        
        # Common Variables
        self.int_1g_var = tk.StringVar(value="0")
        self.int_10g_var = tk.StringVar(value="48")
        self.int_40g_var = tk.StringVar(value="6")
        self.vlans_text = tk.StringVar()
        
        # Standalone Variables
        self.sa_hostname_var = tk.StringVar()
        self.sa_mgmt_ip_var = tk.StringVar()
        self.sa_mgmt_gw_var = tk.StringVar()
        self.sa_motd_var = tk.StringVar(value="Authorized Access Only")
        
        # vPC Variables
        self.vpc_domain_id_var = tk.StringVar(value="1")
        self.vpc_kpa_vrf_var = tk.StringVar(value="management") # Or dedicated keepalive VRF
        self.vpc_pl_id_var = tk.StringVar(value="1")
        
        self.vpc_p_hostname_var = tk.StringVar()
        self.vpc_p_mgmt_ip_var = tk.StringVar()
        self.vpc_p_mgmt_gw_var = tk.StringVar()
        self.vpc_p_kpa_src_var = tk.StringVar() 
        
        self.vpc_s_hostname_var = tk.StringVar()
        self.vpc_s_mgmt_ip_var = tk.StringVar()
        self.vpc_s_mgmt_gw_var = tk.StringVar()
        self.vpc_s_kpa_src_var = tk.StringVar() 
        
        self._create_widgets()

    def _create_widgets(self):
        # Top Frame: Mode and Model
        top_frame = ttk.LabelFrame(self.root, text="System Settings", padding=10)
        top_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(top_frame, text="Mode:").pack(side="left", padx=5)
        ttk.Radiobutton(top_frame, text="Standalone", variable=self.mode_var, value="Standalone", command=self._toggle_mode).pack(side="left", padx=5)
        ttk.Radiobutton(top_frame, text="vPC Pair", variable=self.mode_var, value="vPC Pair", command=self._toggle_mode).pack(side="left", padx=5)
        
        ttk.Separator(top_frame, orient="vertical").pack(side="left", padx=20, fill="y")
        
        ttk.Label(top_frame, text="Switch Model:").pack(side="left", padx=5)
        model_cb = ttk.Combobox(top_frame, textvariable=self.model_var, values=[
            NexusModel.GENERIC, NexusModel.N93180YC_EX, NexusModel.N9336C_FX2, NexusModel.N9348GC_FXP
        ], state="readonly", width=25)
        model_cb.pack(side="left", padx=5)
        model_cb.bind("<<ComboboxSelected>>", self._on_model_change)

        # User Credentials Frame
        auth_frame = ttk.LabelFrame(self.root, text="Admin Credentials (Role: network-admin)", padding=10)
        auth_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(auth_frame, text="Username:").pack(side="left", padx=5)
        ttk.Entry(auth_frame, textvariable=self.admin_user_var, width=20).pack(side="left", padx=5)
        
        ttk.Label(auth_frame, text="Password:").pack(side="left", padx=5)
        ttk.Entry(auth_frame, textvariable=self.admin_pass_var, width=20, show="*").pack(side="left", padx=5)
        
        # Interface Configuration (Generic Only)
        self.int_frame = ttk.LabelFrame(self.root, text="Interface Counts (Generic Mode Only)", padding=10)
        self.int_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(self.int_frame, text="1G Ports:").grid(row=0, column=0, padx=5)
        self.entry_1g = ttk.Entry(self.int_frame, textvariable=self.int_1g_var, width=10)
        self.entry_1g.grid(row=0, column=1, padx=5)
        
        ttk.Label(self.int_frame, text="10G Ports:").grid(row=0, column=2, padx=5)
        self.entry_10g = ttk.Entry(self.int_frame, textvariable=self.int_10g_var, width=10)
        self.entry_10g.grid(row=0, column=3, padx=5)
        
        ttk.Label(self.int_frame, text="40G Ports:").grid(row=0, column=4, padx=5)
        self.entry_40g = ttk.Entry(self.int_frame, textvariable=self.int_40g_var, width=10)
        self.entry_40g.grid(row=0, column=5, padx=5)
        
        # VLAN Configuration
        vlan_frame = ttk.LabelFrame(self.root, text="VLAN Configuration", padding=10)
        vlan_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(vlan_frame, text="Format: 'VLAN_ID VLAN_NAME' (e.g., '10 Data_Vlan'). One per line.").pack(anchor="w")
        self.vlan_input = tk.Text(vlan_frame, height=5, width=80)
        self.vlan_input.pack(fill="x", pady=5)
        ttk.Button(vlan_frame, text="Load VLANs from File", command=self._load_vlans).pack(anchor="e")
        
        # Device Specific Details
        self.details_frame = ttk.Frame(self.root)
        self.details_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        self._create_standalone_widgets()
        self._create_vpc_widgets()
        
        self._toggle_mode()
        self._on_model_change()
        
        # Generate Button
        ttk.Button(self.root, text="Generate Configuration", command=self._generate_config).pack(pady=10)

    def _create_standalone_widgets(self):
        self.sa_frame = ttk.LabelFrame(self.details_frame, text="Standalone Settings", padding=10)
        
        ttk.Label(self.sa_frame, text="Hostname:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        ttk.Entry(self.sa_frame, textvariable=self.sa_hostname_var, width=30).grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(self.sa_frame, text="Management IP:").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        ttk.Entry(self.sa_frame, textvariable=self.sa_mgmt_ip_var, width=30).grid(row=1, column=1, padx=5, pady=5)
        
        ttk.Label(self.sa_frame, text="Management Gateway:").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        ttk.Entry(self.sa_frame, textvariable=self.sa_mgmt_gw_var, width=30).grid(row=2, column=1, padx=5, pady=5)
        
        ttk.Label(self.sa_frame, text="MOTD:").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        ttk.Entry(self.sa_frame, textvariable=self.sa_motd_var, width=50).grid(row=3, column=1, padx=5, pady=5)

    def _create_vpc_widgets(self):
        self.vpc_frame = ttk.LabelFrame(self.details_frame, text="vPC Pair Settings", padding=10)
        
        # vPC Global
        ttk.Label(self.vpc_frame, text="vPC Domain ID:").grid(row=0, column=0, sticky="e", padx=5)
        ttk.Entry(self.vpc_frame, textvariable=self.vpc_domain_id_var, width=10).grid(row=0, column=1, sticky="w", padx=5)
        
        ttk.Label(self.vpc_frame, text="Peer-Keepalive VRF:").grid(row=0, column=2, sticky="e", padx=5)
        ttk.Entry(self.vpc_frame, textvariable=self.vpc_kpa_vrf_var, width=15).grid(row=0, column=3, sticky="w", padx=5)
        
        ttk.Label(self.vpc_frame, text="Peer-Link PO ID:").grid(row=0, column=4, sticky="e", padx=5)
        ttk.Entry(self.vpc_frame, textvariable=self.vpc_pl_id_var, width=10).grid(row=0, column=5, sticky="w", padx=5)
        
        # Primary Device
        p_frame = ttk.LabelFrame(self.vpc_frame, text="Primary Device", padding=5)
        p_frame.grid(row=1, column=0, columnspan=3, sticky="nsew", padx=5, pady=10)
        
        ttk.Label(p_frame, text="Hostname:").grid(row=0, column=0, sticky="e")
        ttk.Entry(p_frame, textvariable=self.vpc_p_hostname_var).grid(row=0, column=1, sticky="w")
        
        ttk.Label(p_frame, text="Mgmt IP:").grid(row=1, column=0, sticky="e")
        ttk.Entry(p_frame, textvariable=self.vpc_p_mgmt_ip_var).grid(row=1, column=1, sticky="w")
        
        ttk.Label(p_frame, text="Mgmt Gateway:").grid(row=2, column=0, sticky="e")
        ttk.Entry(p_frame, textvariable=self.vpc_p_mgmt_gw_var).grid(row=2, column=1, sticky="w")
        
        ttk.Label(p_frame, text="KPA Src IP (Link A):").grid(row=3, column=0, sticky="e")
        ttk.Entry(p_frame, textvariable=self.vpc_p_kpa_src_var).grid(row=3, column=1, sticky="w")
        
        # Secondary Device
        s_frame = ttk.LabelFrame(self.vpc_frame, text="Secondary Device", padding=5)
        s_frame.grid(row=1, column=3, columnspan=3, sticky="nsew", padx=5, pady=10)
        
        ttk.Label(s_frame, text="Hostname:").grid(row=0, column=0, sticky="e")
        ttk.Entry(s_frame, textvariable=self.vpc_s_hostname_var).grid(row=0, column=1, sticky="w")
        
        ttk.Label(s_frame, text="Mgmt IP:").grid(row=1, column=0, sticky="e")
        ttk.Entry(s_frame, textvariable=self.vpc_s_mgmt_ip_var).grid(row=1, column=1, sticky="w")

        ttk.Label(s_frame, text="Mgmt Gateway:").grid(row=2, column=0, sticky="e")
        ttk.Entry(s_frame, textvariable=self.vpc_s_mgmt_gw_var).grid(row=2, column=1, sticky="w")
        
        ttk.Label(s_frame, text="KPA Src IP (Link B):").grid(row=3, column=0, sticky="e")
        ttk.Entry(s_frame, textvariable=self.vpc_s_kpa_src_var).grid(row=3, column=1, sticky="w")

    def _toggle_mode(self):
        mode = self.mode_var.get()
        if mode == "Standalone":
            self.vpc_frame.pack_forget()
            self.sa_frame.pack(fill="both", expand=True)
        else:
            self.sa_frame.pack_forget()
            self.vpc_frame.pack(fill="both", expand=True)

    def _on_model_change(self, event=None):
        model = self.model_var.get()
        if model == NexusModel.GENERIC:
            self.entry_1g.config(state="normal")
            self.entry_10g.config(state="normal")
            self.entry_40g.config(state="normal")
        else:
            self.entry_1g.config(state="disabled")
            self.entry_10g.config(state="disabled")
            self.entry_40g.config(state="disabled")

    def _load_vlans(self):
        filename = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if filename:
            with open(filename, 'r') as f:
                self.vlan_input.delete("1.0", tk.END)
                self.vlan_input.insert("1.0", f.read())

    def _generate_config(self):
        try:
            mode = self.mode_var.get()
            model = self.model_var.get()
            
            # Auth
            user = self.admin_user_var.get().strip()
            password = self.admin_pass_var.get().strip()
            
            vlans = self.vlan_input.get("1.0", tk.END).strip()
            vlan_block = self._generate_vlans(vlans)
            
            # Determine Excluded Ports (used for vPC)
            exclude_ports = []
            vpc_ports = None

            if mode == "vPC Pair":
                vpc_ports = self._get_vpc_ports(model)
                if not vpc_ports and model != NexusModel.GENERIC:
                     pass # Should be handled or generic needs manual
                
                if vpc_ports:
                    exclude_ports.extend(vpc_ports.get('peer_link', []))
                    exclude_ports.extend(vpc_ports.get('keepalive', []))

            # Interface Logic
            if model == NexusModel.GENERIC:
                interface_block = self._generate_interfaces_generic(
                    int(self.int_1g_var.get() or 0),
                    int(self.int_10g_var.get() or 0),
                    int(self.int_40g_var.get() or 0),
                    exclude_ports
                )
            else:
                interface_block = self._generate_interfaces_model(model, exclude_ports)

            if mode == "Standalone":
                hostname = self.sa_hostname_var.get().strip()
                if not hostname: raise ValueError("Hostname is required")
                
                config = self._build_config(
                    hostname=hostname,
                    mgmt_ip=self.sa_mgmt_ip_var.get(),
                    mgmt_gw=self.sa_mgmt_gw_var.get(),
                    motd=self.sa_motd_var.get(),
                    interfaces=interface_block,
                    vlans=vlan_block,
                    model=model,
                    user=user,
                    password=password
                )
                self._save_file(f"{hostname}.txt", config)
                
            else: # vPC Pair
                p_host = self.vpc_p_hostname_var.get().strip()
                s_host = self.vpc_s_hostname_var.get().strip()
                if not p_host or not s_host: raise ValueError("Both Hostnames are required")
                
                domain = self.vpc_domain_id_var.get()
                kpa_vrf = self.vpc_kpa_vrf_var.get()
                pl_id = self.vpc_pl_id_var.get()
                
                if not vpc_ports: raise ValueError("vPC not supported for Generic model in this auto-mode without manual port selection. Use a specific model.")

                # Primary
                p_config = self._build_config(
                    hostname=p_host,
                    mgmt_ip=self.vpc_p_mgmt_ip_var.get(),
                    mgmt_gw=self.vpc_p_mgmt_gw_var.get(),
                    motd=f"{p_host} - {self.vpc_p_mgmt_ip_var.get()} - Restricted",
                    interfaces=interface_block,
                    vlans=vlan_block,
                    model=model,
                    user=user,
                    password=password,
                    is_vpc=True,
                    role="primary",
                    domain=domain,
                    kpa_vrf=kpa_vrf,
                    pl_id=pl_id,
                    kpa_local=self.vpc_p_kpa_src_var.get(),
                    kpa_remote=self.vpc_s_kpa_src_var.get(),
                    vpc_ports=vpc_ports
                )
                self._save_file(f"{p_host}_primary.txt", p_config)
                
                # Secondary
                s_config = self._build_config(
                    hostname=s_host,
                    mgmt_ip=self.vpc_s_mgmt_ip_var.get(),
                    mgmt_gw=self.vpc_s_mgmt_gw_var.get(),
                    motd=f"{s_host} - {self.vpc_s_mgmt_ip_var.get()} - Restricted",
                    interfaces=interface_block,
                    vlans=vlan_block,
                    model=model,
                    user=user,
                    password=password,
                    is_vpc=True,
                    role="secondary",
                    domain=domain,
                    kpa_vrf=kpa_vrf,
                    pl_id=pl_id,
                    kpa_local=self.vpc_s_kpa_src_var.get(),
                    kpa_remote=self.vpc_p_kpa_src_var.get(),
                    vpc_ports=vpc_ports
                )
                self._save_file(f"{s_host}_secondary.txt", s_config)
            
            messagebox.showinfo("Success", "Configuration(s) generated successfully!")
            
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _get_vpc_ports(self, model):
        # Returns: {'peer_link': [list of ports], 'keepalive': [list of ports]}
        if model == NexusModel.N93180YC_EX:
            return {'peer_link': ['Ethernet1/53', 'Ethernet1/54'], 'keepalive': ['Ethernet1/47', 'Ethernet1/48']} 
        elif model == NexusModel.N9336C_FX2:
            return {'peer_link': ['Ethernet1/35', 'Ethernet1/36'], 'keepalive': ['Ethernet1/33', 'Ethernet1/34']}
        elif model == NexusModel.N9348GC_FXP:
            # Copper ports 47/48 for Keepalive (1G), QSFP 53/54 for PeerLink
            return {'peer_link': ['Ethernet1/53', 'Ethernet1/54'], 'keepalive': ['Ethernet1/47', 'Ethernet1/48']}
        return None

    def _generate_interfaces_generic(self, c_1g, c_10g, c_40g, exclude_ports=[]):
        c = []
        idx = 1
        for i in range(c_1g):
            p = f"Ethernet1/{idx}"
            if p not in exclude_ports:
                c.append(f"interface {p}\n  description 1G Port\n  switchport\n  no shutdown")
            idx += 1
        for i in range(c_10g):
            p = f"Ethernet1/{idx}"
            if p not in exclude_ports:
                c.append(f"interface {p}\n  description 10G Port\n  switchport\n  no shutdown")
            idx += 1
        for i in range(c_40g):
            p = f"Ethernet1/{idx}"
            if p not in exclude_ports:
                c.append(f"interface {p}\n  description 40G Uplink\n  switchport\n  no shutdown")
            idx += 1
        return "\n".join(c)

    def _generate_interfaces_model(self, model, exclude_ports=[]):
        c = []
        
        def add_int(name, desc, mode="access", speed=None):
            if name in exclude_ports: return
            c.append(f"interface {name}")
            c.append(f"  description {desc}")
            c.append(f"  switchport mode {mode}")
            c.append(f"  shutdown")
            
        if model == NexusModel.N93180YC_EX:
            # 1-48: 10/25G SFP+
            for i in range(1, 49):
                add_int(f"Ethernet1/{i}", "Host Port (10/25G)")
            # 49-54: 40/100G QSFP28
            for i in range(49, 55):
                add_int(f"Ethernet1/{i}", "Uplink (40/100G)", "trunk")
                
        elif model == NexusModel.N9336C_FX2:
            # 1-36: 40/100G QSFP28
            for i in range(1, 37):
                add_int(f"Ethernet1/{i}", "Port (40/100G)")
                
        elif model == NexusModel.N9348GC_FXP:
            # 1-48: 100M/1G Base-T
            for i in range(1, 49):
                add_int(f"Ethernet1/{i}", "Host Port (1G Base-T)")
            # 49-52: 10/25G SFP28
            for i in range(49, 53):
                add_int(f"Ethernet1/{i}", "Uplink (10/25G)", "trunk")
            # 53-54: 40/100G QSFP28
            for i in range(53, 55):
                add_int(f"Ethernet1/{i}", "Uplink (40/100G)", "trunk")
        
        return "\n".join(c)

    def _generate_vlans(self, vlan_text):
        lines = ["\n! VLAN Configuration"]
        if not vlan_text: return ""
        for line in vlan_text.splitlines():
            parts = line.strip().split()
            if len(parts) >= 1:
                v_id = parts[0]
                v_name = parts[1] if len(parts) > 1 else f"VLAN_{v_id}"
                lines.append(f"vlan {v_id}")
                lines.append(f"  name {v_name}")
        return "\n".join(lines)

    def _build_config(self, hostname, mgmt_ip, mgmt_gw, motd, interfaces, vlans, model, user=None, password=None, is_vpc=False, role=None, domain=None, kpa_vrf=None, pl_id=None, kpa_local=None, kpa_remote=None, vpc_ports=None):
        c = []
        c.append(f"hostname {hostname}")
        c.append(f"!\nbanner motd # {motd} #\n!")
        
        # User Configuration
        if user and password:
            c.append(f"\n! User Credentials")
            c.append(f"username {user} password {password} role network-admin")
            
        # Features & Aliases
        c.append("\n! Features")
        c.append("feature telnet")
        c.append("feature bash-shell")
        c.append("feature interface-vlan")
        c.append("feature lacp")
        c.append("feature lldp")
        c.append("feature vpc")
        c.append("nv overlay evpn")
        
        c.append("\n! Aliases")
        c.append("alias command wr copy running-config startup-config")
        c.append("alias command shint show interface status")
        c.append("alias command shintd show interface description")
        
        c.append("\n! Management")
        c.append("interface mgmt0")
        c.append(f"  ip address {mgmt_ip}")
        c.append("  vrf member management")
        c.append(f"vrf context management")
        c.append(f"  ip route 0.0.0.0/0 {mgmt_gw}")
        
        c.append(vlans)
        
        if is_vpc and vpc_ports:
            c.append("\n! vPC Configuration")
            
            kpa_ports = vpc_ports['keepalive']
            c.append(f"\n! vPC Keepalive Link (Ports: {', '.join(kpa_ports)})")
            
            c.append("interface port-channel100")
            c.append("  description vPC Keepalive Link")
            c.append(f"  vrf member {kpa_vrf}")
            c.append(f"  ip address {kpa_local}") 
            c.append("  no shutdown")
            
            for p in kpa_ports:
                c.append(f"interface {p}")
                c.append("  description vPC Keepalive Member")
                c.append("  no switchport")
                c.append("  channel-group 100 mode active")
                c.append("  no shutdown")
            
            c.append(f"\n! vPC Domain")
            c.append(f"vpc domain {domain}")
            c.append(f"  role priority {10 if role == 'primary' else 20}")
            c.append(f"  peer-keepalive destination {kpa_remote.split('/')[0]} source {kpa_local.split('/')[0]} vrf {kpa_vrf}")
            c.append("  peer-gateway")
            c.append("  auto-recovery")
            c.append("  ip arp synchronize")
            
            # Peer Link
            pl_ports = vpc_ports['peer_link']
            c.append(f"\n! vPC Peer-Link (Ports: {', '.join(pl_ports)})")
            c.append(f"interface port-channel{pl_id}")
            c.append("  description vPC Peer-Link")
            c.append("  switchport mode trunk")
            c.append("  vpc peer-link")
            c.append("  spanning-tree port type network")
            c.append("  no shutdown")
            
            for p in pl_ports:
                c.append(f"interface {p}")
                c.append("  description vPC Peer-Link Member")
                c.append("  switchport mode trunk")
                c.append(f"  channel-group {pl_id} mode active")
                c.append("  no shutdown")

        c.append(f"\n! Interfaces")
        c.append(interfaces)
        
        return "\n".join(c)

    def _save_file(self, filename, content):
        with open(filename, "w") as f:
            f.write(content)

if __name__ == "__main__":
    root = tk.Tk()
    app = NexusConfiguratorGUI(root)
    root.mainloop()

# Cisco Nexus Configurator - Advanced v2 Documentation

## 1. Overview
The **Cisco Nexus Configurator** is a specialized automation tool designed to streamline the generation of Cisco NX-OS configurations. It provides a user-friendly graphical interface (GUI) to handle both standalone switch setups and complex vPC (virtual Port Channel) pair configurations.

The application ensures that generated configurations follow industry best practices, including proper management setup, standard feature activation (LACP, LLDP, VPC, etc.), and consistent interface naming conventions.

---

## 2. Technical Stack
- **Language**: Python 3.x
- **GUI Framework**: `Tkinter` / `ttk` (Standard Python GUI library)
- **Deployment**: Bundled as a standalone executable using `PyInstaller`.
- **Output Format**: Plaintext Cisco IOS/NX-OS CLI commands (`.txt` files).

---

## 3. Core Features

### 3.1 Mode Selection
- **Standalone**: Focuses on a single device configuration.
- **vPC Pair**: Simultaneously generates configurations for two switches (Primary and Secondary) with automatic negotiation of Peer-Link and Peer-Keepalive parameters.

### 3.2 System Configuration
- **Hostname**: Customizable device naming.
- **Management**: Configuration of `mgmt0` interface including IP, Gateway, and VRF management context.
- **Admin Credentials**: Automatically configures a local user with the `network-admin` role for immediate access.
- **Banner (MOTD)**: Configures a customizable login banner.

### 3.3 VLAN Management
- **Manual Input**: Multi-line text area for defining VLAN IDs and Names.
- **File Import**: Support for loading VLAN lists from external text files.
- **Dynamic Names**: Automatically assigns default names (e.g., `VLAN_10`) if names are not provided.

### 3.4 Interface Generation
- **Generic Mode**: Manual assignment of 1G, 10G, and 40G port counts.
- **Model-Specific Mode**: Pre-defined hardware mappings for specific Nexus models.
- **Automatic vPC Reserve**: Intelligently identifies and reserves ports for Keepalive and Peer-Links to prevent configuration conflicts.

### 3.5 Automation & Best Practices
- **Features**: Automatically enables `telnet`, `bash-shell`, `interface-vlan`, `lacp`, `lldp`, `vpc`, and `evpn`.
- **Aliases**: Injects time-saving aliases:
  - `wr` -> `copy running-config startup-config`
  - `shint` -> `show interface status`
  - `shintd` -> `show interface description`

---

## 4. Supported Hardware Models

| Model | Port Density | vPC Peer-Link | vPC Keepalive |
| :--- | :--- | :--- | :--- |
| **N93180YC-EX** | 48x10/25G + 6x40/100G | Eth1/53-54 | Eth1/47-48 |
| **N9336C-FX2** | 36x40/100G QSFP28 | Eth1/35-36 | Eth1/33-34 |
| **N9348GC-FXP** | 48x1G + 4x10/25G + 2x40G | Eth1/53-54 | Eth1/47-48 |
| **Generic** | User Defined | Manual | Manual |

---

## 5. Usage Guide

### 5.1 Standalone Setup
1. Select **Standalone** mode.
2. Choose the specific **Switch Model** or "Generic".
3. Enter **Hostname**, **Mgmt IP**, and **Mgmt Gateway**.
4. (Optional) Provide **Admin Password**.
5. Input **VLANs** (one per line, e.g., `100 DMZ`).
6. Click **Generate Configuration**. A `.txt` file named after the hostname will be created.

### 5.2 vPC Pair Setup
1. Select **vPC Pair** mode.
2. Choose a specific model (required for automatic vPC port selection).
3. Enter details for both **Primary** and **Secondary** switches.
4. Define **Peer-Keepalive Src IPs** for both ends (these should be in the same subnet).
5. Click **Generate Configuration**. Two files will be created: `[Hostname]_primary.txt` and `[Hostname]_secondary.txt`.

---

## 6. Architecture & Logic

### 6.1 Configuration Assembly
The program utilizes a modular assembly pattern in the `_build_config` method:
1. **Header**: Hostname and Banner.
2. **Auth**: User creation.
3. **Features**: Global capability activation.
4. **Aliases**: CLI shortcuts.
5. **Management**: Mgmt0 and VRF routing.
6. **VLANs**: Iterative block generation.
7. **vPC Infrastructure** (if applicable): Port-channel 100 for Keepalive, Domain configuration, and Peer-Link creation.
8. **Interfaces**: Dynamic port-mapping based on hardware profile.

### 6.2 Data Integrity
- **Error Handling**: Validates hostnames and specific vPC constraints before generation.
- **Port Reservation**: The logic ensures that ports used for vPC infrastructure are excluded from the general access/trunk port generation to avoid CLI overlap errors.

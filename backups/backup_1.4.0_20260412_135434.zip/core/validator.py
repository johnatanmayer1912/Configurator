import ipaddress
from typing import List, Dict
from models.device_model import Device

class ValidationError(Exception):
    def __init__(self, report):
        self.report = report
        super().__init__(f"Validation failed: {report['errors']}")

class DeviceValidator:
    def __init__(self):
        self.errors = []

    def validate(self, device: Device) -> Dict:
        """
        Executes all validation rules against the Device model.
        Returns a structured report: {"status": "pass|fail", "errors": []}
        """
        self.errors = []
        
        # 1. IP Validation
        self._validate_ip(device.mgmt_ip, "Management IP")
        if device.vpc:
            self._validate_ip(device.vpc.local_keepalive_ip, "vPC Local Keepalive IP")
            self._validate_ip(device.vpc.remote_keepalive_ip, "vPC Remote Keepalive IP")
            
        # 2. VLAN Uniqueness
        vlan_ids = [v.id for v in device.vlans]
        if len(vlan_ids) != len(set(vlan_ids)):
            duplicates = set([x for x in vlan_ids if vlan_ids.count(x) > 1])
            self.errors.append(f"Duplicate VLAN IDs detected: {duplicates}")
            
        # 3. Interface Uniqueness
        intf_names = [i.name for i in device.interfaces]
        if len(intf_names) != len(set(intf_names)):
            duplicates = set([x for x in intf_names if intf_names.count(x) > 1])
            self.errors.append(f"Duplicate Interface names detected: {duplicates}")
            
        # 4. Interface Modes
        valid_modes = ["access", "trunk", "routed"]
        for intf in device.interfaces:
            if intf.mode not in valid_modes:
                self.errors.append(f"Interface {intf.name} has invalid mode: {intf.mode}. Expected: {valid_modes}")
                
        # 5. vPC Interface Conflicts (reserved ports)
        # Note: In future, this would check against a hardware reserved port list.
        
        status = "pass" if not self.errors else "fail"
        return {
            "status": status,
            "errors": self.errors
        }

    def _validate_ip(self, ip_str: str, label: str):
        if not ip_str:
            self.errors.append(f"{label} is missing")
            return
            
        # Remove cidr if present for simple IP check, or keep it for interface check
        clean_ip = ip_str.split('/')[0]
        try:
            ipaddress.ip_address(clean_ip)
        except ValueError:
            self.errors.append(f"Invalid {label} format: {ip_str}")

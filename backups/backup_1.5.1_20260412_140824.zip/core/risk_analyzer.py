from typing import List, Dict

class RiskAnalyzer:
    def __init__(self):
        # High impact keywords
        self.risk_patterns = {
            "CRITICAL": ["vpc domain", "reload", "reboot", "no feature"],
            "HIGH": ["shutdown", "spanning-tree", "vlan", "no vpc"], 
            "MEDIUM": ["interface", "no shutdown"],
            "LOW": ["hostname", "description", "alias"]
        }

    def analyze(self, config_lines: List[str]) -> Dict:
        """
        Scans configuration lines for high-impact commands and categorizes risk.
        """
        findings = []
        overall_score = "LOW"
        
        # Simple pattern matching
        for line in config_lines:
            line_clean = line.strip().lower()
            if not line_clean or line_clean.startswith('!'):
                continue
                
            for level, patterns in self.risk_patterns.items():
                for p in patterns:
                    if p in line_clean:
                        findings.append({
                            "level": level,
                            "command": line.strip(),
                            "reason": f"Matches risk pattern: '{p}'"
                        })
                        # Upgrade overall score if needed
                        if self._is_higher(level, overall_score):
                            overall_score = level
                            
        return {
            "overall_risk": overall_score,
            "findings": findings
        }

    def _is_higher(self, level1: str, level2: str) -> bool:
        order = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        return order.index(level1) > order.index(level2)

    def generate_report(self, analysis: Dict) -> str:
        report = []
        report.append("==========================================")
        report.append("       CONFIGURATION RISK ASSESSMENT      ")
        report.append("==========================================")
        report.append(f"OVERALL RISK LEVEL: {analysis['overall_risk']}")
        report.append(f"TOTAL FINDINGS: {len(analysis['findings'])}")
        report.append("------------------------------------------")
        
        if not analysis['findings']:
            report.append("No high-risk commands detected.")
        else:
            for f in analysis['findings']:
                report.append(f"[{f['level']}] {f['command']}")
                report.append(f"   ↳ {f['reason']}")
                
        report.append("==========================================")
        return "\n".join(report)

import os
import sys
from jinja2 import Environment, FileSystemLoader
from models.device_model import Device

class ConfigRenderer:
    def __init__(self, template_dir: str = None):
        if template_dir is None:
            # Handle PyInstaller _MEIPASS for bundled templates
            if getattr(sys, 'frozen', False):
                # When running as an EXE
                base_path = sys._MEIPASS
                template_dir = os.path.join(base_path, "templates")
            else:
                # When running as a script
                base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                template_dir = os.path.join(base_path, "templates")
            
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True
        )

    def render_device_config(self, device: Device, template_name: str = "nxos_base.j2") -> str:
        """
        Renders the configuration for a given device using the specified template.
        """
        template = self.env.get_template(template_name)
        return template.render(device=device)

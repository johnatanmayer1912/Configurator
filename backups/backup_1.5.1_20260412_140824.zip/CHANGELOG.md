# Changelog

All notable changes to this project will be documented in this file.

## [1.5.1] - 2026-04-12
### Added
- Implemented PyInstaller distribution layer for offline standalone EXE creation.
- Added support for internal resource path handling using `sys._MEIPASS` for bundled templates.

## [1.5.0] - 2026-04-12
### Added
- Implemented full configuration build pipeline (`pipelines/build_pipeline.py`).
- Automated generation of `config.txt`, `diff.txt`, and `risk.txt`.
- Integrated `RiskAnalyzer` for automated CLI security auditing.

## [1.4.0] - 2026-04-12
### Added
- Integrated a comprehensive validation engine (`core/validator.py`).
- Pre-rendering checks for: Duplicate VLANs, IP address syntax, interface conflicts, and mode validity.
- Structured validation reporting in the GUI.

## [1.3.0] - 2026-04-12
### Added
- Migrated configuration generation to Jinja2 templates (`templates/nxos_base.j2`).
- Introduced modular `ConfigRenderer` for decoupled template handling.
- Optimized vPC logic for template-driven assembly.

## [1.2.0] - 2026-04-12
### Added
- Introduced structured data models using Python dataclasses (`Device`, `VLAN`, `Interface`, `VPCConfig`).
- Migrated Engine and UI to use structured objects for configuration generation.
- Enhanced internal data validation via model-based structures.

## [1.1.0] - 2026-04-12
### Changed
- Refactored project structure into layered architecture:
  - Created `/core`, `/modules`, `/models`, `/templates`, `/pipelines`.
  - Moved logic into modular components in `/modules/`.
  - Introduced `core/engine.py` as the orchestration layer.
  - Isolated models into `models/`.

## [1.0.0] - 2026-04-12
### Added
- Initial project structure.
- Governance system: Versioning, Changelog, Logging, and Backup utility.

# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2026-04-12
### Changed
- Refactored project structure into layered architecture:
  - Created `/core`, `/modules`, `/models`, `/templates`, `/pipelines`.
  - Moved logic into modular components in `/modules/`.
  - Introduced `core/engine.py` as the orchestration layer.
  - Isolated models into `models/`.

## [1.0.0] - 2026-04-12
### Added
- Initial project structure.
- Governance system: Versioning, Changelog, Logging, and Backup utility.

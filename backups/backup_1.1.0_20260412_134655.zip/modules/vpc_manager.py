def build_vpc_config(c, role, domain, kpa_vrf, pl_id, kpa_local, kpa_remote, vpc_ports):
    c.append("\n! vPC Configuration")
    
    kpa_ports = vpc_ports['keepalive']
    c.append(f"\n! vPC Keepalive Link (Ports: {', '.join(kpa_ports)})")
    
    c.append("interface port-channel100")
    c.append("  description vPC Keepalive Link")
    c.append(f"  vrf member {kpa_vrf}")
    c.append(f"  ip address {kpa_local}") 
    c.append("  no shutdown")
    
    for p in kpa_ports:
        c.append(f"interface {p}")
        c.append("  description vPC Keepalive Member")
        c.append("  no switchport")
        c.append("  channel-group 100 mode active")
        c.append("  no shutdown")
    
    c.append(f"\n! vPC Domain")
    c.append(f"vpc domain {domain}")
    c.append(f"  role priority {10 if role == 'primary' else 20}")
    c.append(f"  peer-keepalive destination {kpa_remote.split('/')[0]} source {kpa_local.split('/')[0]} vrf {kpa_vrf}")
    c.append("  peer-gateway")
    c.append("  auto-recovery")
    c.append("  ip arp synchronize")
    
    # Peer Link
    pl_ports = vpc_ports['peer_link']
    c.append(f"\n! vPC Peer-Link (Ports: {', '.join(pl_ports)})")
    c.append(f"interface port-channel{pl_id}")
    c.append("  description vPC Peer-Link")
    c.append("  switchport mode trunk")
    c.append("  vpc peer-link")
    c.append("  spanning-tree port type network")
    c.append("  no shutdown")
    
    for p in pl_ports:
        c.append(f"interface {p}")
        c.append("  description vPC Peer-Link Member")
        c.append("  switchport mode trunk")
        c.append(f"  channel-group {pl_id} mode active")
        c.append("  no shutdown")

def generate_vlans(vlan_text):
    lines = ["\n! VLAN Configuration"]
    if not vlan_text: return ""
    for line in vlan_text.splitlines():
        parts = line.strip().split()
        if len(parts) >= 1:
            v_id = parts[0]
            v_name = parts[1] if len(parts) > 1 else f"VLAN_{v_id}"
            lines.append(f"vlan {v_id}")
            lines.append(f"  name {v_name}")
    return "\n".join(lines)

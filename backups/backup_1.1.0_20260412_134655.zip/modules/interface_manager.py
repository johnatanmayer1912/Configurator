from models.nexus_models import NexusModel

def get_vpc_ports(model):
    # Returns: {'peer_link': [list of ports], 'keepalive': [list of ports]}
    if model == NexusModel.N93180YC_EX:
        return {'peer_link': ['Ethernet1/53', 'Ethernet1/54'], 'keepalive': ['Ethernet1/47', 'Ethernet1/48']} 
    elif model == NexusModel.N9336C_FX2:
        return {'peer_link': ['Ethernet1/35', 'Ethernet1/36'], 'keepalive': ['Ethernet1/33', 'Ethernet1/34']}
    elif model == NexusModel.N9348GC_FXP:
        return {'peer_link': ['Ethernet1/53', 'Ethernet1/54'], 'keepalive': ['Ethernet1/47', 'Ethernet1/48']}
    return None

def generate_interfaces_generic(c_1g, c_10g, c_40g, exclude_ports=[]):
    c = []
    idx = 1
    for i in range(c_1g):
        p = f"Ethernet1/{idx}"
        if p not in exclude_ports:
            c.append(f"interface {p}\n  description 1G Port\n  switchport\n  no shutdown")
        idx += 1
    for i in range(c_10g):
        p = f"Ethernet1/{idx}"
        if p not in exclude_ports:
            c.append(f"interface {p}\n  description 10G Port\n  switchport\n  no shutdown")
        idx += 1
    for i in range(c_40g):
        p = f"Ethernet1/{idx}"
        if p not in exclude_ports:
            c.append(f"interface {p}\n  description 40G Uplink\n  switchport\n  no shutdown")
        idx += 1
    return "\n".join(c)

def generate_interfaces_model(model, exclude_ports=[]):
    c = []
    
    def add_int(name, desc, mode="access", speed=None):
        if name in exclude_ports: return
        c.append(f"interface {name}")
        c.append(f"  description {desc}")
        c.append(f"  switchport mode {mode}")
        c.append(f"  shutdown")
        
    if model == NexusModel.N93180YC_EX:
        for i in range(1, 49):
            add_int(f"Ethernet1/{i}", "Host Port (10/25G)")
        for i in range(49, 55):
            add_int(f"Ethernet1/{i}", "Uplink (40/100G)", "trunk")
            
    elif model == NexusModel.N9336C_FX2:
        for i in range(1, 37):
            add_int(f"Ethernet1/{i}", "Port (40/100G)")
            
    elif model == NexusModel.N9348GC_FXP:
        for i in range(1, 49):
            add_int(f"Ethernet1/{i}", "Host Port (1G Base-T)")
        for i in range(49, 53):
            add_int(f"Ethernet1/{i}", "Uplink (10/25G)", "trunk")
        for i in range(53, 55):
            add_int(f"Ethernet1/{i}", "Uplink (40/100G)", "trunk")
    
    return "\n".join(c)

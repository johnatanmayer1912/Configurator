from modules.vpc_manager import build_vpc_config

class ConfigEngine:
    def build_config(self, hostname, mgmt_ip, mgmt_gw, motd, interfaces, vlans, model, user=None, password=None, is_vpc=False, role=None, domain=None, kpa_vrf=None, pl_id=None, kpa_local=None, kpa_remote=None, vpc_ports=None):
        c = []
        c.append(f"hostname {hostname}")
        c.append(f"!\nbanner motd # {motd} #\n!")
        
        # User Configuration
        if user and password:
            c.append(f"\n! User Credentials")
            c.append(f"username {user} password {password} role network-admin")
            
        # Features & Aliases
        c.append("\n! Features")
        c.append("feature telnet")
        c.append("feature bash-shell")
        c.append("feature interface-vlan")
        c.append("feature lacp")
        c.append("feature lldp")
        c.append("feature vpc")
        c.append("nv overlay evpn")
        
        c.append("\n! Aliases")
        c.append("alias command wr copy running-config startup-config")
        c.append("alias command shint show interface status")
        c.append("alias command shintd show interface description")
        
        c.append("\n! Management")
        c.append("interface mgmt0")
        c.append(f"  ip address {mgmt_ip}")
        c.append("  vrf member management")
        c.append(f"vrf context management")
        c.append(f"  ip route 0.0.0.0/0 {mgmt_gw}")
        
        c.append(vlans)
        
        if is_vpc and vpc_ports:
            build_vpc_config(c, role, domain, kpa_vrf, pl_id, kpa_local, kpa_remote, vpc_ports)

        c.append(f"\n! Interfaces")
        c.append(interfaces)
        
        return "\n".join(c)

    def save_config(self, filename, content):
        with open(filename, "w") as f:
            f.write(content)

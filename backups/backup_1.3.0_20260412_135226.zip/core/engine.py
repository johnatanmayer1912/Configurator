from models.device_model import Device
from core.renderer import ConfigRenderer

class ConfigEngine:
    def __init__(self):
        self.renderer = ConfigRenderer()

    def build_config(self, device: Device) -> str:
        """
        Builds the configuration string for a device using the templating engine.
        """
        # Delegating configuration generation to the Jinja2 Renderer
        return self.renderer.render_device_config(device)

    def save_config(self, filename: str, content: str):
        """
        Saves the generated configuration to a file.
        """
        with open(filename, "w") as f:
            f.write(content)

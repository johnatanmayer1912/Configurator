import os
from jinja2 import Environment, FileSystemLoader
from models.device_model import Device

class ConfigRenderer:
    def __init__(self, template_dir: str = None):
        if template_dir is None:
            # Default to /templates relative to project root
            template_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")
            
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True
        )

    def render_device_config(self, device: Device, template_name: str = "nxos_base.j2") -> str:
        """
        Renders the configuration for a given device using the specified template.
        """
        template = self.env.get_logger_template(template_name) if hasattr(self.env, 'get_logger_template') else self.env.get_template(template_name)
        # Using simple env.get_template
        template = self.env.get_template(template_name)
        return template.render(device=device)

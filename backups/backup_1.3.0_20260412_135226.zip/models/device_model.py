from dataclasses import dataclass, field
from typing import List, Optional
from models.vlan_model import VLAN
from models.interface_model import Interface

@dataclass
class VPCConfig:
    domain_id: int
    keepalive_vrf: str
    peer_link_id: int
    role: str # primary, secondary
    local_keepalive_ip: str
    remote_keepalive_ip: str

@dataclass
class Device:
    hostname: str
    mgmt_ip: str
    mgmt_gw: str
    model: str
    vlans: List[VLAN] = field(default_factory=list)
    interfaces: List[Interface] = field(default_factory=list)
    vpc: Optional[VPCConfig] = None
    motd: str = "Authorized Access Only"
    admin_user: str = "admin"
    admin_password: str = ""

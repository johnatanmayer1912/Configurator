from dataclasses import dataclass
from typing import Optional

@dataclass
class Interface:
    name: str
    mode: str = "access" # access, trunk, routed
    vlan: Optional[int] = None
    description: Optional[str] = None
    shutdown: bool = True

# Changelog

All notable changes to this project will be documented in this file.

## [1.3.0] - 2026-04-12
### Added
- Migrated configuration generation to Jinja2 templates (`templates/nxos_base.j2`).
- Introduced modular `ConfigRenderer` for decoupled template handling.
- Optimized vPC logic for template-driven assembly.

## [1.2.0] - 2026-04-12
### Added
- Introduced structured data models using Python dataclasses (`Device`, `VLAN`, `Interface`, `VPCConfig`).
- Migrated Engine and UI to use structured objects for configuration generation.
- Enhanced internal data validation via model-based structures.

## [1.1.0] - 2026-04-12
### Changed
- Refactored project structure into layered architecture:
  - Created `/core`, `/modules`, `/models`, `/templates`, `/pipelines`.
  - Moved logic into modular components in `/modules/`.
  - Introduced `core/engine.py` as the orchestration layer.
  - Isolated models into `models/`.

## [1.0.0] - 2026-04-12
### Added
- Initial project structure.
- Governance system: Versioning, Changelog, Logging, and Backup utility.

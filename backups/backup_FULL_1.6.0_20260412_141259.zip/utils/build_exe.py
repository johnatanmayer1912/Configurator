import os
import sys
import datetime
import subprocess

def build_exe():
    # 1. Discover Version
    version = "1.0.0"
    if os.path.exists("VERSION"):
        with open("VERSION", "r") as f:
            version = f.read().strip()
            
    # 2. Format Metadata
    date_str = datetime.datetime.now().strftime("%Y-%m-%d")
    exe_name = f"ConfigAuthority_v{version}_{date_str}"
    
    # 3. Build Command
    cmd = [
        "pyinstaller",
        "--noconfirm",
        "--onefile",
        "--windowed",
        "--add-data", "templates;templates",
        "--add-data", "VERSION;.",
        "--name", exe_name,
        "main.py"
    ]
    
    print(f"Starting Institutional Build for {exe_name}...")
    try:
        subprocess.run(cmd, check=True)
        print(f"\nSUCCESS: Institutional EXE located in /dist/{exe_name}.exe")
    except Exception as e:
        print(f"\nERROR: Build failed - {e}")

if __name__ == "__main__":
    build_exe()

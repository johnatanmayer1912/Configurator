from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from models.device_model import Device, VPCConfig
from models.vlan_model import VLAN
from models.interface_model import Interface
from pipelines.build_pipeline import ConfigurationPipeline
from core.validator import DeviceValidator, ValidationError

app = FastAPI(title="Configuration Authority API", version="1.6.0")
pipeline = ConfigurationPipeline()
validator = DeviceValidator()

class VLANInput(BaseModel):
    id: int
    name: str

class InterfaceInput(BaseModel):
    name: str
    mode: str = "access"
    vlan: Optional[int] = None
    description: Optional[str] = None
    shutdown: bool = False

class DeviceInput(BaseModel):
    hostname: str
    mgmt_ip: str
    mgmt_gw: str
    model: str = "Generic"
    vlans: List[VLANInput]
    interfaces: List[InterfaceInput]
    motd: str = "Authorized Access Only"

@app.get("/version")
def get_version():
    return {"version": pipeline.version, "status": "operational"}

@app.post("/validate")
def validate_device(input: DeviceInput):
    # Convert API model to internal dataclass
    vlans = [VLAN(v.id, v.name) for v in input.vlans]
    interfaces = [Interface(i.name, i.mode, i.vlan, i.description, i.shutdown) for i in input.interfaces]
    
    device = Device(
        hostname=input.hostname,
        mgmt_ip=input.mgmt_ip,
        mgmt_gw=input.mgmt_gw,
        model=input.model,
        vlans=vlans,
        interfaces=interfaces,
        motd=input.motd
    )
    
    report = validator.validate(device)
    return report

@app.post("/generate-config")
def generate_config(input: DeviceInput):
    # Conversion logic
    vlans = [VLAN(v.id, v.name) for v in input.vlans]
    interfaces = [Interface(i.name, i.mode, i.vlan, i.description, i.shutdown) for i in input.interfaces]
    
    device = Device(
        hostname=input.hostname,
        mgmt_ip=input.mgmt_ip,
        mgmt_gw=input.mgmt_gw,
        model=input.model,
        vlans=vlans,
        interfaces=interfaces,
        motd=input.motd
    )
    
    try:
        msg = pipeline.execute(device)
        return {"status": "success", "message": msg}
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=e.report["errors"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

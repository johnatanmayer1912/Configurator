import os
import difflib
from datetime import datetime
from typing import Optional

from models.device_model import Device
from core.engine import ConfigEngine
from core.risk_analyzer import RiskAnalyzer

class ConfigurationPipeline:
    def __init__(self, output_dir: str = "configs/history"):
        self.engine = ConfigEngine()
        self.risk_analyzer = RiskAnalyzer()
        self.output_dir = output_dir
        
        # Phase 7: Historical storage path
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

        # Version Discovery
        self.version = "UNKNOWN"
        try:
            v_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "VERSION")
            with open(v_path, "r") as f:
                self.version = f.read().strip()
        except:
            pass

    def execute(self, device: Device, base_config: str = "") -> str:
        """
        Full pipeline execution: Model -> Validation -> Render -> Diff -> Risk -> Output
        """
        # Phase 6: Prepare Metadata
        metadata = {
            "version": self.version,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "mode": "vPC Pair" if device.vpc else "Standalone",
            "system": "Configuration Authority System"
        }

        # 1. Validation & Render
        # Passing metadata to the renderer via the engine
        # We need to update engine.build_config to accept metadata
        config_text = self.engine.build_config(device, metadata=metadata)
        
        # 2. Diff Generation
        diff_text = self.generate_diff(base_config, config_text)
        
        # 3. Risk Analysis
        analysis = self.risk_analyzer.analyze(config_text.splitlines())
        risk_report = self.risk_analyzer.generate_report(analysis)
        
        # 4. Save Outputs (Phase 7: Path and Naming)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        prefix = f"{device.hostname}_{timestamp}"
        
        self._write_file(f"{prefix}_config.txt", config_text)
        self._write_file(f"{prefix}_diff.txt", diff_text)
        self._write_file(f"{prefix}_risk.txt", risk_report)
        
        return f"Pipeline execution successful. Artifacts stored in {self.output_dir}/{device.hostname}*"

    def generate_diff(self, a: str, b: str) -> str:
        a_lines = a.splitlines(keepends=True)
        b_lines = b.splitlines(keepends=True)
        diff = difflib.unified_diff(a_lines, b_lines, fromfile="baseline", tofile="proposed")
        return "".join(diff)

    def _write_file(self, filename: str, content: str):
        path = os.path.join(self.output_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

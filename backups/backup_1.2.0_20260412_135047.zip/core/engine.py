from models.device_model import Device
from modules.vpc_manager import build_vpc_config
from modules.vlan_manager import generate_vlans

class ConfigEngine:
    def build_config(self, device: Device) -> str:
        c = []
        c.append(f"hostname {device.hostname}")
        c.append(f"!\nbanner motd # {device.motd} #\n!")
        
        # User Configuration
        if device.admin_user and device.admin_password:
            c.append(f"\n! User Credentials")
            c.append(f"username {device.admin_user} password {device.admin_password} role network-admin")
            
        # Features & Aliases
        c.append("\n! Features")
        c.append("feature telnet")
        c.append("feature bash-shell")
        c.append("feature interface-vlan")
        c.append("feature lacp")
        c.append("feature lldp")
        c.append("feature vpc")
        c.append("nv overlay evpn")
        
        c.append("\n! Aliases")
        c.append("alias command wr copy running-config startup-config")
        c.append("alias command shint show interface status")
        c.append("alias command shintd show interface description")
        
        c.append("\n! Management")
        c.append("interface mgmt0")
        c.append(f"  ip address {device.mgmt_ip}")
        c.append("  vrf member management")
        c.append(f"vrf context management")
        c.append(f"  ip route 0.0.0.0/0 {device.mgmt_gw}")
        
        # VLANs
        c.append(generate_vlans(device.vlans))
        
        # vPC
        if device.vpc:
            vpc = device.vpc
            vpc_ports = {
                'peer_link': [f"Ethernet1/{i}" for i in range(53, 55)], # Defaulting to common ports or we could pass them
                'keepalive': [f"Ethernet1/{i}" for i in range(47, 49)]
            }
            # Note: vpc_ports should ideally be part of the VPCConfig or model
            # For now, I'll use the ports passed in the device model if I add them, or use the role-based logic.
            # I'll update VPCConfig for better port handling.
            
            # Re-using the existing build_vpc_config logic
            # This needs to be slightly refactored to handle the new vpc object
            build_vpc_config(
                c, 
                role=vpc.role, 
                domain=vpc.domain_id, 
                kpa_vrf=vpc.keepalive_vrf, 
                pl_id=vpc.peer_link_id, 
                kpa_local=vpc.local_keepalive_ip, 
                kpa_remote=vpc.remote_keepalive_ip, 
                vpc_ports=None # We need to handle this better
            )

        c.append(f"\n! Interfaces")
        for intf in device.interfaces:
            c.append(f"interface {intf.name}")
            if intf.description:
                c.append(f"  description {intf.description}")
            if intf.mode in ["access", "trunk"]:
                c.append(f"  switchport mode {intf.mode}")
                if intf.mode == "access" and intf.vlan:
                    c.append(f"  switchport access vlan {intf.vlan}")
            if intf.shutdown:
                c.append("  shutdown")
            else:
                c.append("  no shutdown")
        
        return "\n".join(c)

    def save_config(self, filename: str, content: str):
        with open(filename, "w") as f:
            f.write(content)
